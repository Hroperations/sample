package com.virtusa.view;

public class AdminView {
	public void adminView() {
		System.out.println("=======Admin View======");
	}
}
