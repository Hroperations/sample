package com.virtusa.view;

public class HrView {
	public void hrView() {
		System.out.println("=======Hr View======");
	}
}
