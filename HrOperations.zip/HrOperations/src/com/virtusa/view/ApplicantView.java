package com.virtusa.view;

public class ApplicantView {
	public void applicantView() {
		System.out.println("=======Applicant View======");
	}
}
