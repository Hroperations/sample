package com.virtusa.view;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import com.virtusa.controller.ApplicantController;
import com.virtusa.model.ApplicantModel;

public class ApplicantView {
	ApplicantModel applicantModel=new ApplicantModel();
	ApplicantController applicantController;
	
	public void applicantMainView() throws ClassNotFoundException, SQLException, IOException {
		System.out.println("=======Applicant View======");
		applicantController=new ApplicantController();
		Scanner scanner=new Scanner(System.in);
		System.out.println("1. Search Job");
		System.out.println("2. Application Status");
		System.out.println("3. Result Updates");
		System.out.println("4. Approve or Reject Offer Letter");
		
		System.out.print("Enter option:");
		int option=scanner.nextInt();
			if(option==1){
			applicantController.viewJob();
			System.out.println("\n");
			
			System.out.println("Apply Job");
			ApplicantView applicantView=new ApplicantView();
			applicantView.uploadResume();
		}
		if(option==2){
			applicantController.applicantStatus();
		}
		if(option==3){
			applicantController.resultUpdate();
		}
		else if (option==4){
			/*System.out.print("Enter file Id");
			int fileId=scanner.nextInt();
			ApplicantModel applicantMdl=new ApplicantModel();
			applicantMdl.setFileId(fileId);*/
			applicantController.offerLetter();
		}
		scanner.close();
		
	}
	private void uploadResume() {
		// TODO Auto-generated method stub
		applicantController=new ApplicantController();
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Resume path:");
		String resumepath=scanner.next();
		ApplicantModel applicantModel=new ApplicantModel();
		applicantModel.setResume(resumepath);
		applicantController.applyJob(applicantModel);
		scanner.close();
	}
	public void displayJobDetails(List<ApplicantModel> applicantModelList){
    	for(ApplicantModel applicantModel :applicantModelList){
	
    		System.out.print("\n Job Title:"+applicantModel.getJobTitle());
    		System.out.print("\n Eligibility Criteria:"+applicantModel.getEligibilityCriteria());
    		System.out.println("\n Respective Hr Mail Id:"+applicantModel.getMailId());
    	
    	}
    	}
	
	public void displayApplicationStatus(List<ApplicantModel> applicantModelList) {
		// TODO Auto-generated method stub
		for(ApplicantModel applicantModel :applicantModelList){
			System.out.println("\nApplication Status:"+applicantModel.getApplicationStatus());
		}
	}
	public void storeSuccessful() {
		// TODO Auto-generated method stub
		System.out.println("Resume Updated successfully");
	}
	public void storeUnSuccessful() {
		// TODO Auto-generated method stub
		System.out.println("Resume not Updated successfully");
	}
	public void displayResultUpdate(List<ApplicantModel> applicantModelList) {
		// TODO Auto-generated method stub
		for(ApplicantModel applicantModel :applicantModelList){
			System.out.println("\nResult Update:"+applicantModel.getResultUpdate());
		}
	}
	public void displayOfferLeter(List<ApplicantModel> applicantModelList) throws IOException {
		// TODO Auto-generated method stub
		
		for(ApplicantModel applicantModel :applicantModelList){
		File file=new File("C:\\Users\\pemma\\Desktop\\"+applicantModel.getFile_name());
		file.createNewFile();
	    Writer writer=new FileWriter(file);
		int k=0;
		   System.out.println(applicantModel.getFile_data());
		   String data=null;
		  // while((data=br.readLine())!=null) {
			//   writer.write(data);
		   }//writer.close();
		}
		   
	}
		
	

