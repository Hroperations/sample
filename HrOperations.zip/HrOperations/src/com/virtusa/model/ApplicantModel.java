package com.virtusa.model;

public class ApplicantModel {
	
	private String applicationStatus;
	private String resultUpdate;
	public String getApplicationStatus() {
		return applicationStatus;
	}
	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}
	public String getResultUpdate() {
		return resultUpdate;
	}
	public void setResultUpdate(String resultUpdate) {
		this.resultUpdate = resultUpdate;
	}
	private String resume;
	private int jobId;
	private String jobTitle;
	private String eligibilityCriteria;
	private String mailId;
	
	public String getResume() {
		return resume;
	}
	public void setResume(String resume) {
		this.resume = resume;
	}
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	public String getEligibilityCriteria() {
		return eligibilityCriteria;
	}
	public void setEligibilityCriteria(String eligibilityCriteria) {
		this.eligibilityCriteria = eligibilityCriteria;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	@Override
	public String toString() {
		return "ApplicantModel [applicationStatus=" + applicationStatus + ", resultUpdate=" + resultUpdate + ", resume="
				+ resume + ", jobId=" + jobId + ", jobTitle=" + jobTitle + ", eligibilityCriteria="
				+ eligibilityCriteria + ", mailId=" + mailId + "]";
	}
	
}