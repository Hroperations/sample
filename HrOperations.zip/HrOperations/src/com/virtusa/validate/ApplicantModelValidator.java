package com.virtusa.validate;

import java.util.List;

import com.virtusa.model.ApplicantModel;

	public class ApplicantModelValidator {
		ApplicantModel model=new ApplicantModel();
		public boolean validate(List<ApplicantModel> applicantModelList) {
		boolean result=false;
		if(validApplicationStatus(applicantModelList)){
			while(model.getApplicationStatus().isEmpty()){
			model.getApplicationStatus();
			applicantModelList.add(model);
			}
			result=true;
		}
		return result;
	}
		private boolean validApplicationStatus(List<ApplicantModel> applicantModelList) {
			// TODO Auto-generated method stub
			boolean result=false;
			if(applicantModelList.equals("Approved") || applicantModelList.equals("Rejected")){
				result =true;
			}
			return result;
		}
		
}
