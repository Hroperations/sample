package com.virtusa.entities;

public class Applicant extends User {
  
public Applicant() {
		
	}
	private String applicationStatus;
	private String resultUpdate;
	public String getApplicationStatus() {
		return applicationStatus;
	}
	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}
	public String getResultUpdate() {
		return resultUpdate;
	}
	public void setResultUpdate(String resultUpdate) {
		this.resultUpdate = resultUpdate;
	}
	private Resume resume;
	public Resume getResume() {
		return resume;
	}
	public void setResume(Resume resume) {
		this.resume = resume;
	}
	private Job job;
	public Job getJob() {
		return job;
	}
	public void setJob(Job job) {
		this.job = job;
	}
	private int applicantId;
	public int getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}
	@Override
	public String toString() {
		return "Applicant [applicationStatus=" + applicationStatus + ", resultUpdate=" + resultUpdate + ", resume="
				+ resume + ", job=" + job + ", applicantId=" + applicantId + "]";
	}
	
	
}
