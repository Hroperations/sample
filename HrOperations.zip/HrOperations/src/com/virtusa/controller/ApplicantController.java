package com.virtusa.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.virtusa.factory.FactoryApplicantService;
import com.virtusa.model.ApplicantModel;
import com.virtusa.service.ApplicantService;
import com.virtusa.view.AdminView;
import com.virtusa.view.ApplicantView;

	public class ApplicantController {
	private ApplicantService applicantService;
	public ApplicantController(){
		this.applicantService=FactoryApplicantService.createApplicantService();
		
	}

	public void viewJob() throws ClassNotFoundException, SQLException {
		
		ApplicantView applicantView=new ApplicantView();
		List<ApplicantModel> applicantModelList=applicantService.retrieveJobService();
		applicantView.displayJobDetails(applicantModelList);
		
	}

	public void applyJob(ApplicantModel applicantModel) {
		// TODO Auto-generatd method stub
		ApplicantView applicantView=new ApplicantView();
		String result=applicantService.postResume(applicantModel);
		if(result != null){
			applicantView.storeSuccessful();
		}else{
			
			applicantView.storeUnSuccessful();
		}
		
		
	}

	public void applicantStatus() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		ApplicantView applicantView=new ApplicantView();
		List<ApplicantModel> applicantModelList=applicantService.retrieveApplicationStatus();
		applicantView.displayApplicationStatus(applicantModelList);
		
	}

}
