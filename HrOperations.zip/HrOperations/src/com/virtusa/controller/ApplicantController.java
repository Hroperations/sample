package com.virtusa.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import com.virtusa.factory.FactoryApplicantService;
import com.virtusa.model.ApplicantModel;
import com.virtusa.service.ApplicantService;
import com.virtusa.validate.ApplicantModelValidator;
import com.virtusa.view.ApplicantView;

	public class ApplicantController {
	ApplicantView applicantView=new ApplicantView();
	ApplicantModelValidator applicantModelValidator=new ApplicantModelValidator();
	private ApplicantService applicantService;
	public ApplicantController(){
		this.applicantService=FactoryApplicantService.createApplicantService();
		
	}

	public void viewJob() throws ClassNotFoundException, SQLException {
		
		ApplicantView applicantView=new ApplicantView();
		List<ApplicantModel> applicantModelList=applicantService.retrieveJobService();
		applicantView.displayJobDetails(applicantModelList);
		
	}

	public void applyJob(ApplicantModel applicantModel) {
		String result=applicantService.postResume(applicantModel);
		if(result != null){
			applicantView.storeSuccessful();
		}else{
			
			applicantView.storeUnSuccessful();
		}
		
	}

	public void applicantStatus() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		List<ApplicantModel> applicantModelList=applicantService.retrieveApplicationStatus();
		if(applicantModelValidator.validate(applicantModelList)){
		applicantView.displayApplicationStatus(applicantModelList);
		}
		else{
			System.out.println("Inappropriate Result");
		}
	}

	public void resultUpdate() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		List<ApplicantModel> applicantModelList=applicantService.retreiveResultUpdate();
		applicantView.displayResultUpdate(applicantModelList);
	}

	public void offerLetter() throws IOException, ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		List<ApplicantModel> applicantModelList=applicantService.retreiveOfferLetter();
		applicantView.displayOfferLeter(applicantModelList);
	}

}
