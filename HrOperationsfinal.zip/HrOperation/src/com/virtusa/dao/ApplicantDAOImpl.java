package com.virtusa.dao;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.entities.Applicant;
import com.virtusa.entities.Job;
import com.virtusa.entities.Resume;
import com.virtusa.integrate.ConnectionManager;
import com.virtusa.model.ApplicantModel;

public class ApplicantDAOImpl implements ApplicantDAO {

	ApplicantModel applicantModel=new ApplicantModel();
	@Override
	public List<Job> viewJobs() throws SQLException, ClassNotFoundException {
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=
				connection.prepareStatement(" select j.jobid ,j.jobtitle ,j.eligibilitycriteria ,u.maildid from USERS u INNER join employee e on u.USERID=e.USERID INNER join DEPARTMENT d on e.DEPTID=d.DEPTID INNER join  job j on j.opportunityid=d.deptid and e.designation='Hr'");
		ResultSet resultSet=
				statement.executeQuery();
		List<Job> jobList=new ArrayList<Job>();
		while(resultSet.next()) {
			Job job=new Job();
			job.setJobId(resultSet.getInt("jobid"));
			job.setJobTitle(resultSet.getString("jobtitle"));
			job.setEligibilityCriteria(resultSet.getString("eligibilitycriteria"));
			job.setMailId(resultSet.getString("maildid"));
			jobList.add(job);
		}
		return jobList ;
	}
	@Override
	public boolean postResume(ApplicantModel applicantModel) throws ClassNotFoundException, SQLException, IOException  {
		// TODO Auto-generated method stub
		File pdfFile = new File(applicantModel.getResume());
		byte[] pdfData = new byte[(int) pdfFile.length()];
		DataInputStream dis = new DataInputStream(new FileInputStream(pdfFile));
		dis.readFully(pdfData);
		System.out.println(pdfFile);
		Connection connection =
				ConnectionManager.openConnection();
		PreparedStatement statement = 
				connection.prepareStatement("insert into resume values(?,?)");
		
		statement.setInt(1, 1);
		statement.setBytes(2,pdfData );
		
		int rows=statement.executeUpdate();
		System.out.println(rows);
		ConnectionManager.closeConnection();
		if(rows>0)
			return true;
		else
	
			return false;

		    }
	@Override
	public List<Applicant> viewApplicationStatus() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=null;
			connection = ConnectionManager.openConnection();
			PreparedStatement statement=
					connection.prepareStatement("select applicationstatus from applicant");
			ResultSet resultSet=
					statement.executeQuery();
			List<Applicant>	applicationStatusList=new ArrayList<Applicant>();
			while(resultSet.next()) {
				Applicant applicant=new Applicant();
				applicant.setApplicationStatus(resultSet.getString(1));
				applicationStatusList.add(applicant);
			}
		return applicationStatusList;
	}
	@Override
	public List<Applicant> viewResultStatus() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=null;
		connection = ConnectionManager.openConnection();
		PreparedStatement statement=
				connection.prepareStatement("select resultUpdate from applicant");
		ResultSet resultSet=
				statement.executeQuery();
		List<Applicant>	resultUpdateList=new ArrayList<Applicant>();
		while(resultSet.next()) {
			Applicant applicant=new Applicant();
			applicant.setResultUpdate(resultSet.getString(1));
			resultUpdateList.add(applicant);
		}
	return resultUpdateList;
	}
	@Override
	public List<Applicant> viewOfferLetter() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
				Applicant applicant =new Applicant();
				Connection connection=null;
				connection = ConnectionManager.openConnection();
				PreparedStatement statement=
						connection.prepareStatement("select fileName,fileData from filetable where fileId=?");
				statement.setInt(1,1);
				ResultSet resultSet=
						statement.executeQuery();
				List<Applicant>	offerLetterList=new ArrayList<Applicant>();
				while(resultSet.next()) {
					//fileName=resultSet.getString("fileName");
					//reader=resultSet.getCharacterStream("fileData");
					System.out.println(resultSet.getString(2));
					applicant.setFile_name(resultSet.getString("fileName"));
					applicant.setFile_data(resultSet.getString("fileData"));
					
					offerLetterList.add(applicant);
				 
				}
				System.out.println(offerLetterList);return offerLetterList;
				
	}	
}

