package com.virtusa.validate;

import java.util.ArrayList;
import java.util.List;

import com.virtusa.model.AdminModel;

public class AdminModelValidator {
	public boolean validate(AdminModel adminModel){
		boolean result =false;
		if(validString(adminModel.getJobTitle()) && validString(adminModel.getEligibilityCriteria()) && validNumber(adminModel.getJobId())&& validNumber(adminModel.getOpportunityId()))
		{
			result=true;
		}
		return result;
		
	}

	private boolean validNumber(int number) {
		// TODO Auto-generated method stub
		boolean result=false;
		String data=String.valueOf(number);
		if(data.matches(".*[0-9]")) {
			result=true;
		}
		return result;
	}

	private boolean validString(String val) {
		// TODO Auto-generated method stub
		boolean result=false;
		char chars[]=val.toCharArray();
		List<Character> alphabets=new ArrayList<>();
		for(int i=97;i<=122;i++) {
			alphabets.add((char)i);
		}
		
		for(char ch:chars) {
			if(alphabets.contains(ch)) {
				result=true;
			}else {
				return false;
			}
		}
		return result;
	}
}
