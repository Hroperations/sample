package com.virtusa.validate;

import java.util.ArrayList;
import java.util.List;

import com.virtusa.model.UserModel;

public class UserModelValidator {
public boolean validate(UserModel model) {
		
		boolean result=false;
		
		if(validPassword(model.getPassword())&& validString(model.getUserName())){
			result=true;
		}
		return result;
	}
	
	
	private boolean validPassword(String password) {
		boolean result=false;
		if(password.matches("((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})")){
			result=true;
		}
		return result;

}

	public boolean validString(String val) {
		
		boolean result=false;
		char chars[]=val.toCharArray();
		List<Character> alphabets=new ArrayList<>();
		for(int i=97;i<=122;i++) {
			alphabets.add((char)i);
		}
		
		for(char ch:chars) {
			if(alphabets.contains(ch)) {
				result=true;
			}else {
				return false;
			}
		}
		return result;
	}
}
