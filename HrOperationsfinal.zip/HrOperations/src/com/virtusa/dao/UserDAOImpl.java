package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.virtusa.entities.User;
import com.virtusa.integrate.ConnectionManager;

public class UserDAOImpl implements UserDAO{
	
	User user=new User();
		
	public UserDAOImpl() {}
	static String usernameDb;
	static String passwordDb;
	public boolean userAuth(String userName, String password)throws ClassNotFoundException,SQLException {
		// TODO Auto-generated method stub
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=connection.prepareStatement("select username,password from users");
		ResultSet resultSet=statement.executeQuery();
		
		boolean result=false;
		while(resultSet.next()){
			usernameDb=resultSet.getString(1);
			passwordDb=resultSet.getString(2);
		if(usernameDb.equals(userName))
		{
			
			if(passwordDb.equals(password))
				result=true;
		}
		}
		return result;
	}

	public String retrieveUserType(String userName) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		String returnUserType=null;
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=connection.prepareStatement(" SELECT UPPER(e.designation) as usertype from employee e inner join users u on u.USERID=e.USERID where u.username=?"+
				"union SELECT 'APPLICANT' as usertype from applicant a inner join users u on u.USERID=a.USERID where u.username=? ");
		statement.setString(1,userName);
		statement.setString(2, userName);
		ResultSet resultSet=statement.executeQuery();
		while(resultSet.next()){
			returnUserType=resultSet.getString(1);
		/*String designation=resultSet.getString(1);
		if(designation.contentEquals("Admin")){
			returnUserType="ADMIN";
		}
		else if(designation.contentEquals("Hr")){
			returnUserType="HR";
		}
		else if(designation.contentEquals("Manager")){
			returnUserType="Manager";
		}
		else if(designation.contentEquals("Interviewer")){
			returnUserType="INTERVIEWER";
		}
		else
		{
			returnUserType="APPLICANT";
		}
		}
		for(User user:userList) {
			if(user.getUserName().equals(userName)){
			UserTypes userTypes=user.getUserType();

			switch(userTypes) {
			
			case APPLICANT:
				returnUserType="APPLICANT";
				break;
				
			case ADMIN:
				returnUserType="ADMIN";
				break;
			case INTERVIEWER:
				returnUserType="INTERVIEWER";
				break;
			case HR:
				returnUserType="HR";
				break;	
			case MANAGER:
				returnUserType="MANAGER";
				break;	
				
			}
			
		}
		}*/}
		return returnUserType;	
	
	
	}
}
