package com.virtusa.controller;


import java.sql.SQLException;

import com.virtusa.factory.FactoryAdminService;
import com.virtusa.model.AdminModel;
import com.virtusa.service.AdminService;
import com.virtusa.validate.AdminModelValidator;
import com.virtusa.view.AdminView;

public class AdminController {
	private AdminService adminService;
	AdminView adminView=new AdminView();
	public AdminController(){
		this.adminService=FactoryAdminService.createAdminService();
		
	}

	public void storeJob(AdminModel adminModel) throws ClassNotFoundException, SQLException {
		AdminModelValidator adminModelValidator=new AdminModelValidator();
		if(adminModelValidator.validate(adminModel)){		
		boolean result=adminService.storeJobService(adminModel);
		if(result){
			adminView.storeSuccessful();
		}else{
			
			adminView.storeUnSuccessful();
		}}
		else
		{
			adminView.validationFailedError();
		}
		}
		
	}



