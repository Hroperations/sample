package com.virtusa.utilities;

public enum UserTypes {
	
	ADMIN("ADMIN"),HR("HR"),MANAGER("MANAGER"),INTERVIEWER("INTERVIEWER"),APPLICANT("APPLICANT");
	private String val;
	private UserTypes(String val) {
		this.val=val;
	}
	public String getVal() {
		return val;	
	}

}
